from setuptools import setup
setup(name='eggplant',
      version='1.0',
      py_modules=['eggplant'],
      )
